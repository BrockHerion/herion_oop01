package com.company;

// Brock Herion
// 9/14/2020
// File I/O assignment
// Developed in Intellij Idea on MacOS

/*
I went a little bit overboard on this assignment. I created a student class and a year
enum. The class is used to hold the values of the current user an admin might be entering.
The enum makes the application less prone to potential issues if an invalid year is entered.
For reading from files, I am reading data in and mapping it to user objects. I am then mapping those
to an ArrayList to print out. It's overkill but the challenge was fun.

Some things that should be added later:
1. Better file input handling. Have the user define a path from the start they want to work with
2. Have a global ArrayList of students that gets populated when given a file that has users in it.
    The, we can add any new students to the file and the array list.
3. The ability to search and sort students
4. Some kind of way to get a student and edit his/her data
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.FileWriter;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

public class HerionReadingWriting01 {
    // Constant variables we can use when we are starting the app
    // and validating option 4
    public static final String DEFAULT_NAME = "";
    public static final Year DEFAULT_YEAR = Year.NONE;
    public static final double DEFAULT_GPA = -1.0;

    // Declare initial currentStudent. I set them to these values to easily see
    // if they have had input or not
    public static Student currentStudent = new Student(DEFAULT_NAME, DEFAULT_YEAR, DEFAULT_GPA);

    public static void main(String[] args) {
        // Boolean that controls if the application is running or not
        boolean isRunning = true;

        // We can reuse the scanner throughout our application
        Scanner s = new Scanner(System.in);

        // Clear the screen right away
        clear();

        do {
            printMenuOptions();
            int choice = inputMenuOption(s);

            switch (choice) {
                case 1:
                    String name = inputString(s, "Please enter the students name: ");
                    currentStudent.setName(name);
                    System.out.println();
                    System.out.println("Name was successfully updated to " + currentStudent.name + "\n");
                    clearInput();
                    break;
                case 2:
                    String yearString = inputString(s, "Please enter the students year: ");
                    Year year = Year.findByYear(yearString);
                    System.out.println();
                    if (year == null) {
                        System.out.println("Error: The students year must be either\n" +
                                "\tFreshman\n" +
                                "\tSophomore\n" +
                                "\tJunior\n" +
                                "\tSenior\n");
                        currentStudent.setYear(year.NONE);
                    } else {
                        currentStudent.setYear(year);
                        System.out.println("Year was successfully updated to " + currentStudent.getYear().year + "\n");
                    }
                    clearInput();
                    break;
                case 3:
                    double gpa = inputDouble(s, "Please enter the students GPA: ");
                    System.out.println();
                    if (!validateGpa(gpa)) {
                        System.out.println("Error: The students GPA must be between 0.0 and 4.0\n");
                    } else {
                        currentStudent.setGpa(gpa);
                        System.out.println("GPA was successfully updated to: " + currentStudent.getGpa() + "\n");
                    }
                    clearInput();
                    break;
                case 4:
                    printInformation(currentStudent.getName(), currentStudent.getYear().year, currentStudent.getGpa());
                    System.out.println();
                    clearInput();
                    break;
                case 5:
                    writeDataToFile(currentStudent, s);
                    clearInput();
                    break;
                case 6:
                    readFromFile(s);
                    clearInput();
                    break;
                case 7:
                    isRunning = false;
                    break;
                default:
                    System.out.println("The menu option entered was invalid. Please enter 1-5");
                    clearInput();
                    break;

            }
        } while (isRunning);
        System.out.println("\nGoodbye!\n");
        s.close();
    }

    // Print methods
    public static void printMenuOptions() {
        // Array to store menu items
        String[] menuItems = {
                "1. Enter Students Name",
                "2. Enter Students Academic Year",
                "3. Enter Students GPA",
                "4. Display Current Students Information",
                "5. Write to File",
                "6. Read from File",
                "7. Exit"
        };

        for (String item: menuItems) {
            System.out.println(item);
        }
    }

    public static void printInformation(String name, String year, double gpa) {
        System.out.println();
        System.out.println("The students name is " + name);
        System.out.println("The students year is " + year);
        System.out.println("The students GPS is " + gpa);
    }

    public static void printValidationErrors(ArrayList<String> errors) {
        System.out.println("Please answer all questions");
        for(String error: errors) {
            System.out.println("\t" + error);
        }
    }

    public static void printAllStudents(ArrayList<Student> students) {
        System.out.println();
        if (students.isEmpty()) {
            System.out.println("There are no students in this file");
        } else {
            for(int i = 0; i < students.size(); i++) {
                System.out.println("Student " + (i + 1) + ":\n" +
                        "\tName: " + students.get(i).getName() + "\n" +
                        "\tYear: " + students.get(i).getYear().year + "\n" +
                        "\tGPA: " + students.get(i).getGpa() + "\n");
            }
        }
    }

    // Input methods
    public static int inputMenuOption(Scanner s) {
        String inputPrompt = "Please enter which number you want to answer: ";
        System.out.print(inputPrompt);
        try {
            return s.nextInt();
        } catch (Exception e) {
            // We need this line here to clear the buffer on a bad input,
            // or else we get trapped in a permanent loop
            s.nextLine();
            return -1;
        }
    }

    public static String inputString(Scanner s, String prompt) {
        System.out.print(prompt);

        try {
            // Clear the buffer from the previous input
            s.nextLine();
            return s.nextLine();
        } catch (Exception e) {
            return "";
        }
    }

    public static double inputDouble(Scanner s, String prompt) {
        System.out.print(prompt);

        try {
            return s.nextDouble();
        } catch (Exception e) {
            return -1.0;
        }
    }

    public static boolean validateGpa(double studentGpa) {
        return studentGpa >= 0.0 && studentGpa <= 4.0;
    }

    public static ArrayList<String> validateInformation(String name, Year year, Double gpa) {
        // Store the errors in an array list. We do this because
        // the function doesn't know how many things are valid or
        // invalid till it's run. The number of errors can be between
        // 0 and 3
        ArrayList<String> errors = new ArrayList<>();
        if (name.equals(""))
            errors.add("The students name must be set");
        if (year == Year.NONE)
            errors.add("The students year must be set");
        if (gpa == -1.0)
            errors.add("The students GPA must be set");

        return errors;
    }

    // Methods to read and write to file
    public static void writeDataToFile(Student student, Scanner s) {
        // Cannot write to file if not all fields are entered
        ArrayList<String> errors = validateInformation(student.getName(), student.getYear(), student.getGpa());
        if (!errors.isEmpty()) {
            printValidationErrors(errors);
        } else {
            try {
                System.out.println();
                File outputFile = new File("students-" + LocalDate.now() + ".txt");
                if (!outputFile.exists()) {
                    System.out.println();
                    if (outputFile.createNewFile()) {
                        System.out.println("Created a new file at: " + outputFile.getAbsolutePath());
                    }
                }
                System.out.println("File Found: " + outputFile.getAbsolutePath());
                FileWriter writer = new FileWriter(outputFile, true);
                writer.append(student.toString() + '\n');
                writer.close();
                System.out.println("Successfully added student " + student.getName() + " to file " + outputFile.getName());
                System.out.println();
            } catch (IOException e) {
                System.err.println("An error occurred while writing to file. Check your file location and try again!");
            }
        }
    }

    public static void readFromFile(Scanner s) {
        try {
            String inputPath = inputString(s, "Please enter the path of the file you want to read from: ");
            File inputFile = new File(inputPath);
            if (!inputFile.exists()) {
                System.out.println();
                System.out.println("The file entered was not found at the given path. Please try another path");
            }
            else {
                ArrayList<Student> students = readStudents(inputFile);
                printAllStudents(students);
                System.out.println("Successfully loaded all students from the file!");
            }
        } catch (Exception e) {
            printFileError();
        }
    }

    public static ArrayList<Student> readStudents(File file) {
        ArrayList<Student> students = new ArrayList<>();
        try {
            // ArrayList of all students loaded from the file
            Scanner s = new Scanner(file);
            while (s.hasNextLine()) {
                String studentData = s.nextLine().trim();
                Student student = formatStudent(studentData);
                students.add(student);
            }
            s.close();
            return students;
        } catch (FileNotFoundException e) {
            printFileError();
        } catch (Exception e) {
            System.err.println("An error occurred processing your request. Please try again");
        }
        return students;
    }

    public static Student formatStudent(String studentData) {
        String[] studentFields = studentData.split(",");

        String studentName = studentFields[0];
        Year studentYear = Year.findByYear(studentFields[1]);
        double studentGpa = Double.parseDouble(studentFields[2]);


        Student student = new Student(
                studentName,
                studentYear,
                studentGpa);
        return student;
    }

    public static void printFileError() {
        System.err.println("An error occurred while reading the file. Check your file path and try again");
    }

    // Method to clear the screen
    public static void clearInput() {
        System.out.println("Press the Enter key to continue");

        try {
            // Only read the enter key
            System.in.read();
            clear();
        } catch (Exception ignored) { }
    }

    public static void clear() {
        // ANSI code for move cursor home and clear screen
        // This does not work in non-ANSI terminals, like CMD
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }

    // Enum to hold year types
    // This makes working with currentStudent objects
    // much easier to work with
    public enum Year {
        NONE("None"),
        FRESHMAN("Freshman"),
        SOPHOMORE("Sophomore"),
        JUNIOR("Junior"),
        SENIOR("Senior");

        String year;

        Year(String year) {
            this.year = year;
        }

        public static Year findByYear(String year) {
            for(Year y: values()) {
                if (y.year.equals(year)) {
                    return y;
                }
            }
            return null;
        }
    }

    // Student class to hold data per student
    // If we want to append students to a file,
    // we want an admin to be able to chose which currentStudent
    // to view or edit
    public static class Student {
        private String name;
        private Year year;
        private double gpa;

        public Student() { }

        public Student(String name, Year year, double gpa) {
            this.name = name;
            this.year = year;
            this.gpa = gpa;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public Year getYear() {
            return year;
        }

        public void setYear(Year year) {
            this.year = year;
        }

        public double getGpa() {
            return gpa;
        }

        public void setGpa(double gpa) {
            this.gpa = gpa;
        }

        @Override
        public String toString() {
            return name +
                    "," + year.year +
                    "," + gpa;
        }
    }
}

